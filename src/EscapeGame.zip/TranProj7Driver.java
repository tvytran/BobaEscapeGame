public class TranProj7Driver
{
    public static void main (String[] args)
    {
        TranBobaEscapeRoom boba1 = new TranBobaEscapeRoom();
        boba1.start();
        
        
    }
}